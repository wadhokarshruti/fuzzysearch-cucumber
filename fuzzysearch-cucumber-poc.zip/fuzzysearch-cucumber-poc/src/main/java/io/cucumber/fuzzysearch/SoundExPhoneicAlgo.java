package io.cucumber.fuzzysearch;

import org.apache.commons.codec.language.Caverphone2;
import org.apache.commons.codec.language.DoubleMetaphone;
import org.apache.commons.codec.language.Metaphone;
import org.apache.commons.codec.language.Nysiis;
import org.apache.commons.codec.language.RefinedSoundex;
import org.apache.commons.codec.language.Soundex;

public class SoundExPhoneicAlgo {
    public static void main(String[] args) {
      /*  assertAlgorithm(new Metaphone(), true, "aaa bbb ccc easgasg",
                new String[] { "A", "aaa", "B", "bbb", "KKK", "ccc", "ESKS", "easgasg" });
        assertAlgorithm(new Metaphone(), false, "aaa bbb ccc easgasg",
                new String[] { "A", "B", "KKK", "ESKS" });

        assertAlgorithm(new DoubleMetaphone(), true, "aaa bbb ccc easgasg",
                new String[] { "A", "aaa", "PP", "bbb", "KK", "ccc", "ASKS", "easgasg" });
        assertAlgorithm(new DoubleMetaphone(), false, "aaa bbb ccc easgasg",
                new String[] { "A", "PP", "KK", "ASKS" });

        assertAlgorithm(new Soundex(), true, "aaa bbb ccc easgasg",
                new String[] { "A000", "aaa", "B000", "bbb", "C000", "ccc", "E220", "easgasg" });
        assertAlgorithm(new Soundex(), false, "aaa bbb ccc easgasg",
                new String[] { "A000", "B000", "C000", "E220" });

        assertAlgorithm(new RefinedSoundex(), true, "aaa bbb ccc easgasg",
                new String[] { "A0", "aaa", "B1", "bbb", "C3", "ccc", "E034034", "easgasg" });
        assertAlgorithm(new RefinedSoundex(), false, "aaa bbb ccc easgasg",
                new String[] { "A0", "B1", "C3", "E034034" });

        assertAlgorithm(new Caverphone2(), true, "Darda Karleen Datha Carlene",
                new String[] { "TTA1111111", "Darda", "KLN1111111", "Karleen",
                        "TTA1111111", "Datha", "KLN1111111", "Carlene" });
        assertAlgorithm(new Caverphone2(), false, "Darda Karleen Datha Carlene",
                new String[] { "TTA1111111", "KLN1111111", "TTA1111111", "KLN1111111" });

        assertAlgorithm(new Nysiis(), true, "aaa bbb ccc easgasg",
                new String[] { "A", "aaa", "B", "bbb", "C", "ccc", "EASGAS", "easgasg" });
        assertAlgorithm(new Nysiis(), false, "aaa bbb ccc easgasg",
                new String[] { "A", "B", "C", "EASGAS" });*/
    }
}
