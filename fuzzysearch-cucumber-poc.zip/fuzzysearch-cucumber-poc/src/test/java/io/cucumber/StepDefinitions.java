package io.cucumber;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.fuzzysearch.FuzzySearchModel;
import io.cucumber.fuzzysearch.FuzzyStringMatchSearch;
import io.cucumber.fuzzysearch.WriteDataToExcel;

import java.io.IOException;
import java.util.Arrays;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * @author Shruti Wadhokar
 */
public class StepDefinitions {
    private final FuzzySearchModel searchModel = new FuzzySearchModel();

    @Given("^multiple addresses (.*) from the demographic API for a customer$")
    public void i_have_address_from_demographic_api(String demographicAddressesInput) {
        String[] demographicAddressesArray = demographicAddressesInput.split(";");
        searchModel.setDemographicAddresses(Arrays.asList(demographicAddressesArray));
    }

    @When("^customer enters (.*) non-standard address in the request$")
    public void i_send_address_in_request(String addressFromRequest) {
        searchModel.setAddressFromRequest(addressFromRequest);
    }

    @When("^cutoff is (\\d+)$")
    public void i_have_cutoff(int givenCutOff) {
        searchModel.setGivenCutOff(givenCutOff);
    }

    @Then("^Know the match score$")
    public void my_matched_score_is() {
        FuzzyStringMatchSearch search = new FuzzyStringMatchSearch();
        search.extractBestMatch(searchModel);
        System.out.println("matched score: " + searchModel.getFuzzyWuzzyMatchedScore());
        System.out.println("matched result: " + searchModel.getFuzzyWuzzyMatchedValue());
        search.ratcliffObershelpJSS(searchModel);
        search.cosineDistanceApacheCommons(searchModel);
        WriteDataToExcel writeDataToExcel = new WriteDataToExcel();
        try {
            writeDataToExcel.writeOrUpdate(searchModel);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
